package com.lti.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.lti.model.Farmer;
import com.lti.model.Login;
import com.lti.model.PotentialCrop;
import com.lti.service.IFarmerService;


@Controller

public class FarmerController {
	@Autowired
	private IFarmerService iFarmerService;
	
	public void setIFarmerService(IFarmerService iFarmerService) {
		this.iFarmerService = iFarmerService;
	}
	
	@RequestMapping(value="/farmer")
	public String gotofarmerregpage(Model model) {
	model.addAttribute("farmer",new Farmer());
		return "FarmerRegistration";
	}
	// To add a farmer
			@RequestMapping(value = "/add", 
					method = RequestMethod.POST)
			public String addFarmer(
					@ModelAttribute("farmer") 
					@Valid Farmer farmer, 
					BindingResult result, 
					Model model,HttpSession session) {
				if(!result.hasErrors())
				{// new farmer, add it
						this.iFarmerService.addFarmer(farmer);
						
						session.setAttribute("farmerId", farmer.getFarmerId());
				}
					return "redirect:/login";
				}
		
			
			@RequestMapping(value = "/farmerlogin")
			public String LoginPage(Model model) {
				model.addAttribute("farmer",new Farmer());
				return "FarmerLogin";
			}
					
		@RequestMapping(value = "/farmerloginprocess", 
					method = RequestMethod.POST)
			public ModelAndView farmerLogin(
					@ModelAttribute("farmer") 
					Farmer farmer, 
					BindingResult result, 
					Model model,HttpSession session) {
			ModelAndView mav=new ModelAndView();
				if(this.iFarmerService.loginFarmer(farmer))
				{
				    session.setAttribute("username",farmer.getEmail());
					session.setAttribute("password",farmer.getPassword());
				
					System.out.println(" "+ session.getAttribute("username"));

					System.out.println(" "+ session.getAttribute("password"));

					System.out.println(" "+ session.getAttribute("farmerId"));
					/*Farmer farmer=this.iFarmerService.getfarmer(session);
					//create a query in dao to retrieve Farmer object on the basis of Login object 
					//after this point call that service
					//whatever  Farmer reference is created that you store in model
				modelmap.addAttribute("login",login);
				modelmap.addAttribute("farmer",farmer);*/
					mav.addObject("id", farmer.getFarmerId());
					mav.setViewName("HomeFarmer");
					return mav;
				}
				else
				{
					mav.setViewName("FarmerLogin");
					return mav;
				}
				
		}
		
		@RequestMapping(value="/sellcrop")
		public String sellCrop(Model model) {
		model.addAttribute("potentialcrop",new PotentialCrop());
			return "CropSell";
		}
		
		@RequestMapping(value="/sellcropprocess", 
				method = RequestMethod.POST)
		public String addCrop(@ModelAttribute("potentialcrop") 
					@Valid PotentialCrop potentialcrop, 
					BindingResult result, 
					Model model,HttpSession session) {
			potentialcrop.setRequestStatus("PENDING");
			potentialcrop.setFarmer((Farmer)session.getAttribute("farmer"));
			this.iFarmerService.addCrop(potentialcrop);
			return "HomeFarmer";
			
		}
		@RequestMapping(value="/signout",method= RequestMethod.GET)
		public String signout(HttpSession session)
		{
			session.invalidate();
			return "FarmerLogin";
		}
		

		
	/*	@RequestMapping(value="/cropstatus")
		public String cropStatus()
		{
			this.iFarmerService.listAllCrops();
		}
		*/
}