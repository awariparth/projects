package com.lti.dao;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import com.lti.model.Farmer;
import com.lti.model.Login;
import com.lti.model.PotentialCrop;
@Repository
public class FarmerDaoImpl implements IFarmerDao{
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	private static final Logger logger = 			
			LoggerFactory.getLogger(FarmerDaoImpl.class);
	public void addFarmers(Farmer farmer) {
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(farmer);
		logger.info("Farmer details saved successfully as: "+farmer);
		tx.commit();
		session.close();
		
	}
	@Override
	public boolean loginFarmers(Farmer farmer) {
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		String email=farmer.getEmail();
		String password=farmer.getPassword();
		String query="from Farmer f where f.email=:email and f.password=:password";
		Query q=session.createQuery(query);
		q.setString("email", email);
		q.setString("password",password);
		List<Login> farmerList=q.list();
		tx.commit();
		session.close();
		if(farmerList.size()==0)
			return false;
		else
			return true;
		
	}

	@Override
	public void addCrops(PotentialCrop potentialcrop) {
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
	
		session.save(potentialcrop);
		logger.info("Crop details saved successfully as: "+potentialcrop);
		tx.commit();
		session.close();
	}
	/*@Override
	public Farmer getfarmer(HttpSession session) {
		Farmer farmer=null;
		Session session1=this.sessionFactory.openSession();
		Transaction tx=session1.beginTransaction();
		String email=(String)session.getAttribute("username");
		String query="from Farmer f,Login l where f.userId=l.userId and l.email=:email";	
		Query q=session1.createQuery(query);
		q.setString("email",email);
		List <Farmer> flist =q.list();
		Iterator itr = flist.iterator();
		while(itr.hasNext())
		{
		farmer=(Farmer)itr.next();
		}
		return farmer;
	}*/
	

}
