package com.lti.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lti.model.AcceptedBid;
import com.lti.model.Bidder;
import com.lti.model.FinalCrop;
import com.lti.model.PotentialCrop;
import com.lti.service.IBidderService;

@Controller
public class BidderController {
	@Autowired
	private IBidderService iBidderService;

	public void setiBidderService(IBidderService iBidderService) {
		this.iBidderService = iBidderService;
	}
	
	@RequestMapping(value="/bidder")
	public String gotobidderregpage(Model model) {
	model.addAttribute("bidder",new Bidder());
		return "BidderRegistration";
	}
	// To add a farmer
			@RequestMapping(value = "/bidderadd", 
					method = RequestMethod.POST)
			public String addBidder(
					@ModelAttribute("bidder") 
					@Valid Bidder bidder, 
					BindingResult result, 
					Model model) {
						// new farmer, add it
						this.iBidderService.addBidder(bidder);
					return "redirect:/login";
				}
			@RequestMapping(value = "/bidderlogin")
			public String LoginPage1(Model model) {
				model.addAttribute("bidder",new Bidder());
				return "BidderLogin";
			}					
		@RequestMapping(value = "/bidderloginprocess", 
					method = RequestMethod.POST)
			public String bidderLogin(
					@ModelAttribute("bidder") 
					@Valid Bidder bidder, 
					BindingResult result, 
					Model model,HttpSession session) 
		{
				if(this.iBidderService.loginBidder(bidder))
				{
				Bidder logBidder = this.iBidderService.returnBidder(bidder);
				session.setAttribute("bidder",logBidder);
				session.setAttribute("bidderId",logBidder.getBidderId());
				session.setAttribute("biddername", logBidder.getBidderName());
				model.addAttribute("bidderId", session.getAttribute("bidderId"));
				List<FinalCrop> finalCrop =this.iBidderService.listAllCrops();
				session.setAttribute("Finalcrop", finalCrop);
					return "HomeBidder";
				}
				else
					return "redirect:/bidderlogin";
		}
		
		@RequestMapping(value="/biddersignout",method= RequestMethod.GET)
		public String signout(Model model ,HttpSession session)
		{
			session.invalidate();
			model.addAttribute("bidder",new Bidder());
			return "BidderLogin";
		}
		@RequestMapping(value="placebid/biddersignout",method= RequestMethod.GET)
		public String placebidsignout(Model model ,HttpSession session)
		{
			session.invalidate();
			model.addAttribute("bidder",new Bidder());
			return "BidderLogin";
		}

		@RequestMapping("/placebid/{id}")
		public String placeBid(
				@PathVariable("id") int id,Model model,HttpSession session) 
		{
			session.setAttribute("cropId", id);
			model.addAttribute("cropId",id);
			
			FinalCrop placeBid=this.iBidderService.placeBid(id);
			
			long baseAmount=placeBid.getBaseAmount();
			session.setAttribute("baseAmount", baseAmount);
		Long bidAmount=placeBid.getBidAmount();
			session.setAttribute("bidAmount", bidAmount);
			
			
			System.out.println("we are in controller of placebid and baseamount is" +baseAmount);

			System.out.println("we are in the controller of place bit and bid amount is"+bidAmount);
			model.addAttribute("placeBid",placeBid);
			return "BidForm";
			
		}
		
		@RequestMapping("/placebid/successbidding")
		public String afterbid(@ModelAttribute("placeBid") 
		@Valid FinalCrop placeBid, 
		BindingResult result, 
		Model model,HttpSession session,HttpServletRequest req)
		
		
			{
			System.out.println("we in successbid and cropID is");
			int id=(int)session.getAttribute("cropId");
			System.out.println(id);
			
		long newBid=(long)(Long.valueOf(req.getParameter("newBid")));
		
		System.out.println("the string format of baseamount is "+req.getParameter("baseamount"));
		long baseAmount=(long)(Long.valueOf(req.getParameter("baseamount")));
		System.out.println("long form of baseamount is"+(baseAmount+1));
		System.out.println("the string format of bidAmount is "+req.getParameter("bidAmount"));
		long bidAmount=(long)(Long.valueOf(req.getParameter("bidAmount")));
		System.out.println("long form of baseamount is"+(bidAmount+1));
		
		/*Long bidAmount=Long.parseLong(req.getParameter("bidAmount"));
		long bidamount1=bidAmount.longValue();*/
		//System.out.println("incremented bid amount"+bidAmount+1);
		if(newBid >=baseAmount && newBid>=bidAmount)
		{
		
		this.iBidderService.successBid(placeBid,id);
			
			List<FinalCrop> finalCrop =this.iBidderService.listAllCrops();
			
			session.setAttribute("Finalcrop", finalCrop);
			System.out.println("we are in successbid and final crop values are"+finalCrop);
			
			return "HomeBidder";
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Enter valid bid");
			return "BidForm";
		}
		
		}
		


		@RequestMapping("/winningbid")
		public String viewBids(Model model,HttpSession session)
		{
			int bidderId=(int)session.getAttribute("bidderId");
			List<AcceptedBid> bidList=this.iBidderService.listBids(bidderId);
			model.addAttribute("bidList",bidList);
			return"Winbid";
		}
		//@RequestMapping("/viewwinbid/{id}")
		
	/*	public String acceptCrop(
				@PathVariable("id") int id,Model model) 
		{
			this.iAdminService.acceptCrop(id);
			this.iAdminService.insertFinal();
			List<PotentialCrop> croplist=this.iAdminService.listAllCrops();
			model.addAttribute("Croplist", croplist);
			return "AdminHome";
		}*/
		
		

}